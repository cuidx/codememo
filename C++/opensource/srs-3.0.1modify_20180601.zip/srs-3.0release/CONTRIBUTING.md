First of all, thank you for considering contributing to SRS. It's people like you that make SRS a great live streaming cluster.

Pelease read https://github.com/activeadmin/activeadmin/blob/master/CONTRIBUTING.md
